package com.example.brixs_webview_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
