import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import '../constants.dart';
import '../main.dart' show WebViewScreen;

/// Onboarding screen with app details and a slider to proceed to the webview
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  double _sliderValue = 0.0;
  bool _canProceed = false;
  bool _isDragging = false;
  
  // The distance the handle can travel (Track width - Handle width).
  // This value is determined dynamically in the LayoutBuilder. 
  double _travelDistance = 0.0; 
  bool _isNavigating = false; // Flag to prevent multiple navigation attempts

  // The fixed size of the circular handle
  static const double _handleSize = 54.0;
  // The horizontal padding inside the slider container (8 on each side)
  static const double _innerPadding = 8.0 * 2;

  @override
  void initState() {
    super.initState();
    // Width calculation is now done in LayoutBuilder.
  }

  /// Handles the continuous movement of the slider handle based on drag input.
  void _onHorizontalDragUpdate(DragUpdateDetails details) {
    // We only proceed if we know the total distance the handle can travel.
    if (!_isDragging || _travelDistance == 0.0 || _isNavigating) {
      return;
    }

    final double deltaX = details.delta.dx;
    
    // The core fix: we calculate the change in value based on the 
    // fractional displacement.
    final double valueChange = deltaX / _travelDistance;
    final double newValue = _sliderValue + valueChange;

    // Clamp value between 0.0 and 1.0
    final double clampedValue = newValue.clamp(0.0, 1.0);

    setState(() {
      _sliderValue = clampedValue;
      _canProceed = clampedValue >= 0.9;
    });

    // Navigate immediately when the slider is nearly full
    if (_canProceed && clampedValue >= 0.95) {
      _navigateToWebView();
    }
  }

  void _onHorizontalDragStart(DragStartDetails details) {
    // Allowing drag to start immediately
    setState(() {
      _isDragging = true;
    });
  }

  void _onHorizontalDragEnd(DragEndDetails details) {
    setState(() {
      _isDragging = false;
    });

    // Check if slider is complete when drag ends
    if (_sliderValue >= 0.95) {
      _navigateToWebView();
    } else {
      // Snap back to start if drag is released before completion (better UX)
      setState(() {
        _sliderValue = 0.0;
        _canProceed = false;
      });
    }
  }

  void _navigateToWebView() {
    if (_isNavigating || !mounted) return;
    
    setState(() {
      _isNavigating = true; // Set flag to prevent double entry
    });

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) =>
            const WebViewScreen(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 800),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.backgroundColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppConstants.primaryColor,
              AppConstants.backgroundColor,
              AppConstants.secondaryColor,
            ],
          ),
        ),
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final screenHeight = constraints.maxHeight;
              final screenWidth = constraints.maxWidth;

              // Responsive sizing based on screen dimensions
              final logoSize = screenWidth * 0.4; // 40% of screen width, max 200
              final animationSize = screenWidth * 0.3; // 30% of screen width, max 150
              final topSpacing = screenHeight * 0.08; // 8% of screen height
              final animationSpacing = screenHeight * 0.02; // 2% of screen height

              return Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.06), // 6% horizontal padding
                child: Column(
                  children: [
                    SizedBox(height: topSpacing),

                    Image.asset(
                      'assets/images/brix_trans.png',
                      width: logoSize.clamp(120, 200),
                      height: logoSize.clamp(120, 200),
                    ),

                    SizedBox(height: animationSpacing),

                    // Lottie Animation below logo
                    SizedBox(
                      width: animationSize.clamp(100, 150),
                      height: animationSize.clamp(100, 150),
                      child: Lottie.asset(
                        'assets/animations/Block_Loading.json',
                        fit: BoxFit.contain,
                        repeat: true,
                        animate: true,
                      ),
                    ),

                    const SizedBox(height: 15),

                    // App Information Section
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.all(screenWidth * 0.06), // Responsive padding
                        margin: EdgeInsets.symmetric(vertical: screenHeight * 0.02),
                        decoration: BoxDecoration(
                          color: AppConstants.primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: AppConstants.primaryColor.withOpacity(0.2),
                            width: 1,
                          ),
                        ),
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              _buildFeatureItem(
                                icon: Icons.security,
                                title: 'Secure Transactions',
                                description: 'Safe and encrypted purchase process',
                                screenWidth: screenWidth,
                              ),

                              SizedBox(height: screenHeight * 0.04),

                              _buildFeatureItem(
                                icon: Icons.speed,
                                title: 'Fast & Reliable',
                                description: 'Quick loading and smooth experience',
                                screenWidth: screenWidth,
                              ),

                              SizedBox(height: screenHeight * 0.04),

                              _buildFeatureItem(
                                icon: Icons.support_agent,
                                title: '24/7 Support',
                                description: 'Always here to help with your purchases',
                                screenWidth: screenWidth,
                              ),

                              SizedBox(height: screenHeight * 0.04),

                              // Terms and Privacy
                              Text(
                                'By continuing, you agree to our Terms of Service and Privacy Policy',
                                style: TextStyle(
                                  fontSize: screenWidth * 0.03, // Responsive font size
                                  color: AppConstants.accentColor.withOpacity(0.6),
                                  height: 1.4,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              SizedBox(height: screenHeight * 0.08),
                              Text(
                                'Slide to Continue',
                                style: TextStyle(
                                  fontSize: screenWidth * 0.04, // Responsive font size
                                  fontWeight: FontWeight.w500,
                                  color: AppConstants.accentColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // Slider Section
                    Column(
                      children: [
                        SizedBox(height: screenHeight * 0.02),

                        // Custom Slider using LayoutBuilder to determine available drag space
                        LayoutBuilder(
                          builder: (context, constraints) {
                            // Total available width for the GestureDetector's child Container.
                            final double totalWidth = constraints.maxWidth;

                            // Inner width is TotalWidth - inner horizontal padding
                            final double innerWidth = totalWidth - _innerPadding;

                            // Available distance for the handle to travel (Inner Width - Handle Size)
                            final double calculatedTravelDistance = innerWidth - _handleSize;

                            // FIX: Directly set the _travelDistance variable in this scope.
                            // This ensures it is available for drag handlers immediately.
                            _travelDistance = calculatedTravelDistance;

                            // The total width the animated container should take up, including the handle size.
                            final double animatedContainerWidth = _handleSize + (_sliderValue * _travelDistance);

                            return GestureDetector(
                              onHorizontalDragStart: _onHorizontalDragStart,
                              onHorizontalDragUpdate: _onHorizontalDragUpdate,
                              onHorizontalDragEnd: _onHorizontalDragEnd,
                              child: Container(
                                height: screenHeight * 0.08, // Responsive height
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                decoration: BoxDecoration(
                                  color: AppConstants.primaryColor.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(35),
                                  border: Border.all(
                                    color: _canProceed
                                        ? AppConstants.primaryColor
                                        : AppConstants.accentColor.withOpacity(0.3),
                                    width: 2,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    // Slider Handle (The width expands based on the calculated travel distance)
                                    AnimatedContainer(
                                      duration: const Duration(milliseconds: 200),
                                      // Use the calculated travel distance for movement.
                                      width: animatedContainerWidth.clamp(_handleSize, innerWidth),
                                      height: _handleSize,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: LinearGradient(
                                          colors: _canProceed
                                              ? [AppConstants.primaryColor, AppConstants.secondaryColor]
                                              : [AppConstants.accentColor.withOpacity(0.5), AppConstants.accentColor.withOpacity(0.3)],
                                        ),
                                        boxShadow: _canProceed ? [
                                          BoxShadow(
                                            color: AppConstants.primaryColor.withOpacity(0.4),
                                            blurRadius: 15,
                                            spreadRadius: 3,
                                          ),
                                        ] : null,
                                      ),
                                      // The Icon needs to be right-aligned inside the growing handle container
                                      alignment: Alignment.centerRight,
                                      padding: const EdgeInsets.only(right: 0),
                                      child: Padding(
                                        padding: const EdgeInsets.only(right: 0.0),
                                        child: Icon(
                                          _canProceed ? Icons.check : Icons.arrow_forward,
                                          color: AppConstants.accentColor,
                                          size: screenWidth * 0.06, // Responsive icon size
                                        ),
                                      ),
                                    ),

                                    // Empty space for remaining track (optional, depends on design)
                                    Expanded(
                                      child: Container(),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),

                        SizedBox(height: screenHeight * 0.025),

                        // Progress Indicator
                        Container(
                          width: double.infinity,
                          height: screenHeight * 0.005, // Responsive height
                          decoration: BoxDecoration(
                            color: AppConstants.accentColor.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(2),
                          ),
                          child: FractionallySizedBox(
                            alignment: Alignment.centerLeft,
                            widthFactor: _sliderValue,
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [AppConstants.primaryColor, AppConstants.secondaryColor],
                                ),
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: screenHeight * 0.05),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureItem({
    required IconData icon,
    required String title,
    required String description,
    required double screenWidth,
  }) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(screenWidth * 0.03), // Responsive padding
          decoration: BoxDecoration(
            color: AppConstants.primaryColor.withOpacity(0.7),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: Colors.white,
            size: screenWidth * 0.06, // Responsive icon size
          ),
        ),

        SizedBox(width: screenWidth * 0.04), // Responsive spacing

        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: screenWidth * 0.04, // Responsive font size
                  fontWeight: FontWeight.w600,
                  color: AppConstants.accentColor,
                ),
              ),

              SizedBox(height: screenWidth * 0.01), // Responsive spacing

              Text(
                description,
                style: TextStyle(
                  fontSize: screenWidth * 0.035, // Responsive font size
                  color: AppConstants.accentColor.withOpacity(0.7),
                  height: 1.3,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}