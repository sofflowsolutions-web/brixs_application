import 'package:flutter/material.dart';
import '../constants.dart';
import '../l10n/app_localizations.dart';

/// A beautiful animated loading screen for the BRIXS app
/// Features a pulsing logo with animated loading dots
class BrixsLoadingScreen extends StatefulWidget {
  const BrixsLoadingScreen({super.key});

  @override
  State<BrixsLoadingScreen> createState() => _BrixsLoadingScreenState();
}

class _BrixsLoadingScreenState extends State<BrixsLoadingScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: AppConstants.loadingAnimationDuration,
      vsync: this,
    )..repeat(reverse: true);

    _animation = Tween<double>(
      begin: AppConstants.loadingScaleBegin,
      end: AppConstants.loadingScaleEnd,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: AppLocalizations.of(context)!.loadingText,
      hint: 'Application is loading BRIXS content',
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppConstants.backgroundColor,
              AppConstants.primaryColor,
              AppConstants.backgroundColor,
            ],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Animated BRIXS Logo
              Semantics(
                label: 'BRIXS logo',
                image: true,
                child: AnimatedBuilder(
                  animation: _animation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _animation.value,
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [
                              AppConstants.primaryColor,
                              AppConstants.secondaryColor,
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppConstants.primaryColor.withOpacity(0.3),
                              blurRadius: AppConstants.shadowBlurRadius,
                              spreadRadius: AppConstants.shadowSpreadRadius,
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.currency_bitcoin,
                          color: AppConstants.accentColor,
                          size: AppConstants.logoSize,
                        ),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 30),

              // BRIXS Text
              Semantics(
                label: AppLocalizations.of(context)!.brixsText,
                header: true,
                child: Text(
                  AppLocalizations.of(context)!.brixsText,
                  style: TextStyle(
                    fontSize: AppConstants.titleFontSize,
                    fontWeight: FontWeight.bold,
                    color: AppConstants.accentColor,
                    letterSpacing: 2,
                  ),
                ),
              ),

              const SizedBox(height: 10),

              // Subtitle
              Semantics(
                label: AppLocalizations.of(context)!.loadingText,
                child: Text(
                  AppLocalizations.of(context)!.loadingText,
                  style: TextStyle(
                    fontSize: AppConstants.subtitleFontSize,
                    color: AppConstants.accentColor.withOpacity(0.7),
                    letterSpacing: 1,
                  ),
                ),
              ),

              const SizedBox(height: 40),

              // Loading dots animation
              Semantics(
                label: 'Loading indicator',
                liveRegion: true,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(3, (index) {
                    return AnimatedBuilder(
                      animation: _controller,
                      builder: (context, child) {
                        final delay = index * AppConstants.dotAnimationDelay;
                        final animation = Tween<double>(
                          begin: AppConstants.dotOpacityBegin,
                          end: AppConstants.dotOpacityEnd,
                        ).animate(
                          CurvedAnimation(
                            parent: _controller,
                            curve: Interval(delay, delay + AppConstants.dotAnimationDuration, curve: Curves.easeInOut),
                          ),
                        );

                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: AppConstants.dotSize,
                          height: AppConstants.dotSize,
                          decoration: BoxDecoration(
                            color: AppConstants.accentColor.withOpacity(animation.value),
                            shape: BoxShape.circle,
                          ),
                        );
                      },
                    );
                  }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}