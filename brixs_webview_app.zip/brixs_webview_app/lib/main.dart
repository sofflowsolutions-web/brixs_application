/// BRIXS WebView App
///
/// A Flutter application that provides a native mobile wrapper for the BRIXS purchase website.
/// Features include loading screens, offline detection, error handling, and accessibility support.
///
/// Author: Kilo Code
/// Version: 1.0.0

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';
import 'dart:io' show Platform;
import 'dart:async';
import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'constants.dart';
import 'widgets/loading_screen.dart';
import 'widgets/splash_screen.dart';
import 'l10n/app_localizations.dart';

void main() {
  runApp(const BrixsWebViewApp());
}

/// The root widget of the BRIXS WebView application.
///
/// This widget sets up the MaterialApp with dark theme, localization support,
/// and routes to the main WebViewScreen.
class BrixsWebViewApp extends StatelessWidget {
  const BrixsWebViewApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0), // ✅ FORCE TEXT SCALE 1.0
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: AppConstants.appTitle,
        localizationsDelegates: AppLocalizations.localizationsDelegates,
        supportedLocales: AppLocalizations.supportedLocales,
        theme: ThemeData(
          brightness: Brightness.dark,
          primaryColor: AppConstants.primaryColor,
          scaffoldBackgroundColor: AppConstants.backgroundColor,
          appBarTheme: AppBarTheme(
            backgroundColor: AppConstants.primaryColor,
            elevation: 0,
          ),
          colorScheme: ColorScheme.dark(
            primary: AppConstants.primaryColor,
            secondary: AppConstants.secondaryColor,
            surface: AppConstants.backgroundColor,
          ),
        ),
        home: const SplashScreen(),
      ),
    );
  }
}




/// The main screen widget that displays the BRIXS website in a WebView.
///
/// Features:
/// - Loading screen with animated logo
/// - Offline detection and error handling
/// - Connectivity monitoring
/// - Exit confirmation dialog
/// - Debug overlay for development
/// - Accessibility support
class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

/// State class for WebViewScreen that manages the WebView lifecycle and UI state.
///
/// Handles:
/// - WebView initialization and configuration
/// - Loading state management
/// - Connectivity monitoring
/// - Error handling and recovery
/// - Navigation and back button handling
class _WebViewScreenState extends State<WebViewScreen> {
  /// The WebView controller for managing web content
  late final WebViewController _controller;

  /// Whether the loading screen should be displayed
  bool _isLoading = true;

  /// The current URL being displayed
  String _currentUrl = '';

  /// Timestamp when loading started, used for minimum loading time
  DateTime? _loadingStartTime;

  /// Whether the device is currently offline
  bool _isOffline = false;

  /// Whether a web resource error has occurred
  bool _hasWebError = false;

  /// Connectivity instance for monitoring network status
  late Connectivity _connectivity;

  /// Subscription to connectivity changes
  late StreamSubscription<List<ConnectivityResult>> _connectivitySubscription;

  /// Google Sign In instance
  late GoogleSignIn _googleSignIn;

  /// List of available Google accounts
  List<GoogleSignInAccount> _availableAccounts = [];

  @override
  void initState() {
    super.initState();
    _initializeConnectivity();
    _initializeGoogleSignIn();
    _initializeWebView();
    // Initialize connectivity status
    _checkInitialConnectivity();
  }

  Future<void> _checkInitialConnectivity() async {
    try {
      final results = await _connectivity.checkConnectivity();
      _updateConnectionStatus(results);
    } catch (e) {
      // If connectivity check fails, assume online
      setState(() {
        _isOffline = false;
      });
    }
  }


  void _initializeWebView() {
    // Initialize the WebView controller
    late final PlatformWebViewControllerCreationParams params;

    if (WebViewPlatform.instance is WebKitWebViewPlatform) {
      params = WebKitWebViewControllerCreationParams(
        allowsInlineMediaPlayback: true,
        mediaTypesRequiringUserAction: const <PlaybackMediaTypes>{},
      );
    } else {
      params = const PlatformWebViewControllerCreationParams();
    }

    final WebViewController controller = WebViewController.fromPlatformCreationParams(params);

    controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(AppConstants.backgroundColor)
      ..setUserAgent(AppConstants.userAgent)
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading state - ensure loading screen shows for slower loads
            if (progress < 100) {
              setState(() {
                _isLoading = true;
              });
            } else {
              setState(() {
                _isLoading = false;
              });
            }
          },
          onPageStarted: (String url) {
            // Always show loading screen when navigation starts

            // Security check: Ensure URL is HTTPS
            if (!url.startsWith('https://')) {
              // You might want to show a warning or block the navigation
            }

            _loadingStartTime = DateTime.now();
            setState(() {
              _isLoading = true;
              _currentUrl = url;
            });
          },
          onPageFinished: (String url) {
            // Hide loading screen when page finishes loading (with minimum time)
            final loadingDuration = _loadingStartTime != null
                ? DateTime.now().difference(_loadingStartTime!)
                : Duration.zero;

            // Ensure minimum loading time for better UX
            final remainingTime = AppConstants.minimumLoadingTime - loadingDuration;
            if (remainingTime > Duration.zero) {
              Future.delayed(remainingTime, () {
                if (mounted) {
                  setState(() {
                    _isLoading = false;
                    _currentUrl = url;
                  });
                }
              });
            } else {
              setState(() {
                _isLoading = false;
                _currentUrl = url;
              });
            }

            // Inject CSS to hide browser UI elements and make it look native
            _injectNativeStyling(controller);

            // Inject JavaScript to intercept Google Sign-In buttons
            _injectGoogleSignInInterception(controller);
          },
          onWebResourceError: (WebResourceError error) {
            // Handle web resource errors - only show error if not offline
            if (!_isOffline) {
              setState(() {
                _isLoading = false;
                _hasWebError = true;
              });
            }
          },
        ),
      )
      ..addJavaScriptChannel(
        'Toaster',
        onMessageReceived: (JavaScriptMessage message) {
          // Sanitize the message to prevent potential security issues
          final sanitizedMessage = message.message.length > 200
              ? '${message.message.substring(0, 200)}...'
              : message.message;

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(sanitizedMessage),
              duration: const Duration(seconds: 3),
            ),
          );
        },
      )
      ..addJavaScriptChannel(
        'GoogleSignIn',
        onMessageReceived: (JavaScriptMessage message) {
          // Handle Google Sign In requests from web
          _handleGoogleSignInRequest(message.message);
        },
      )
      ..loadRequest(Uri.parse(AppConstants.websiteUrl));

    // Android-specific configuration
    if (controller.platform is AndroidWebViewController) {
      AndroidWebViewController.enableDebugging(true);
      (controller.platform as AndroidWebViewController)
          .setMediaPlaybackRequiresUserGesture(false);
    }

    _controller = controller;
  }

  void _initializeConnectivity() {
    _connectivity = Connectivity();
    _connectivitySubscription = _connectivity.onConnectivityChanged.listen(
      _updateConnectionStatus,
    );
  }

  void _initializeGoogleSignIn() {
    _googleSignIn = GoogleSignIn();
    _loadAvailableAccounts();
  }

  Future<void> _loadAvailableAccounts() async {
    try {
      // Try to silently sign in first to get current user
      final currentUser = await _googleSignIn.signInSilently();
      if (currentUser != null && mounted) {
        setState(() {
          _availableAccounts = [currentUser];
        });
      } else {
        // If no current user, try to get available accounts
        // Note: Google Sign-In plugin doesn't directly support listing all accounts
        // We'll handle this in the account picker by showing sign-in dialog
        setState(() {
          _availableAccounts = [];
        });
      }
    } catch (e) {
      // Handle error silently - accounts might not be available
      print('Error loading Google accounts: $e');
      if (mounted) {
        setState(() {
          _availableAccounts = [];
        });
      }
    }
  }

  Future<void> _updateConnectionStatus(List<ConnectivityResult> results) async {
    // Only consider offline if ALL results are none (more conservative check)
    final isOffline = results.isNotEmpty && results.every((result) => result == ConnectivityResult.none);
    if (mounted) {
      setState(() {
        _isOffline = isOffline;
        if (!isOffline && _hasWebError) {
          // Try to reload if we come back online and had an error
          _retryLoading();
        }
      });
    }
  }

  void _retryLoading() {
    setState(() {
      _isLoading = true;
      _hasWebError = false;
      _currentUrl = '';
    });
    // Add small delay to ensure state is updated
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) {
        _controller.loadRequest(Uri.parse(AppConstants.websiteUrl));
      }
    });
  }

  @override
  void dispose() {
    _connectivitySubscription.cancel();
    _googleSignIn.disconnect();
    super.dispose();
  }

  void _injectNativeStyling(WebViewController controller) {
    // Inject CSS to hide browser UI elements and make it look more native
    const String css = AppConstants.nativeStylingCss;

    controller.runJavaScript('''
      var style = document.createElement('style');
      style.innerHTML = `$css`;
      document.head.appendChild(style);
    ''');
  }

  void _injectGoogleSignInInterception(WebViewController controller) {
    // Inject JavaScript to intercept Google Sign-In button clicks
    controller.runJavaScript('''
      // Function to intercept Google Sign-In buttons
      function interceptGoogleSignIn() {
        // Look for common Google Sign-In button selectors
        const selectors = [
          'button[data-provider="google"]',
          'button:has-text("Continue with Google")',
          'button:has-text("Sign in with Google")',
          'a[href*="google"]',
          '.google-signin',
          '[data-testid*="google"]',
          'button:contains("Google")'
        ];

        // Add click event listeners to all potential Google buttons
        selectors.forEach(selector => {
          const buttons = document.querySelectorAll(selector);
          buttons.forEach(button => {
            button.addEventListener('click', function(e) {
              e.preventDefault();
              e.stopPropagation();
              // Call the native Google Sign-In handler
              if (window.GoogleSignIn && window.GoogleSignIn.postMessage) {
                window.GoogleSignIn.postMessage(JSON.stringify({
                  action: 'showAccounts'
                }));
              }
              return false;
            });
          });
        });

        // Also intercept form submissions that might be Google auth
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
          if (form.action && form.action.includes('google')) {
            form.addEventListener('submit', function(e) {
              e.preventDefault();
              if (window.GoogleSignIn && window.GoogleSignIn.postMessage) {
                window.GoogleSignIn.postMessage(JSON.stringify({
                  action: 'showAccounts'
                }));
              }
              return false;
            });
          }
        });
      }

      // Run interception after a short delay to ensure DOM is loaded
      setTimeout(interceptGoogleSignIn, 1000);

      // Also run on dynamic content changes (for SPAs)
      const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
          if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
            setTimeout(interceptGoogleSignIn, 500);
          }
        });
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    ''');
  }

  void _handleGoogleSignInRequest(String message) async {
    try {
      // Parse the message to determine what action is needed
      final data = jsonDecode(message);
      final action = data['action'];

      if (action == 'showAccounts') {
        // Show available Google accounts
        await _showGoogleAccountPicker();
      } else if (action == 'signIn') {
        // Sign in with specific account
        final accountIndex = data['accountIndex'] as int?;
        if (accountIndex != null && accountIndex < _availableAccounts.length) {
          await _signInWithAccount(_availableAccounts[accountIndex]);
        }
      }
    } catch (e) {
      print('Error handling Google Sign In request: $e');
    }
  }

  Future<void> _showGoogleAccountPicker() async {
    if (_availableAccounts.isEmpty) {
      // Try to refresh accounts
      await _loadAvailableAccounts();
    }

    // Show account picker dialog - always show options since we can't list all accounts
    if (!mounted) return;

    final selectedOption = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sign in with Google'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_availableAccounts.isNotEmpty) ...[
              // Show current signed-in account
              ..._availableAccounts.map((account) {
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: account.photoUrl != null
                        ? NetworkImage(account.photoUrl!)
                        : null,
                    child: account.photoUrl == null
                        ? Text(account.displayName?[0] ?? '?')
                        : null,
                  ),
                  title: Text(account.displayName ?? 'Unknown'),
                  subtitle: Text(account.email),
                  onTap: () => Navigator.of(context).pop('use_current'),
                );
              }),
              const Divider(),
            ],
            ListTile(
              leading: const Icon(Icons.add),
              title: const Text('Add another account'),
              subtitle: const Text('Sign in with a different Google account'),
              onTap: () => Navigator.of(context).pop('add_account'),
            ),
            ListTile(
              leading: const Icon(Icons.account_circle),
              title: const Text('Choose from available accounts'),
              subtitle: const Text('Select from accounts on this device'),
              onTap: () => Navigator.of(context).pop('choose_account'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );

    if (selectedOption == 'use_current' && _availableAccounts.isNotEmpty) {
      await _signInWithAccount(_availableAccounts.first);
    } else if (selectedOption == 'add_account' || selectedOption == 'choose_account') {
      await _showGoogleSignInDialog();
    }
  }

  Future<void> _showGoogleSignInDialog() async {
    try {
      // Sign out first to allow account selection
      await _googleSignIn.signOut();

      final account = await _googleSignIn.signIn();
      if (account != null) {
        await _signInWithAccount(account);
      }
    } catch (e) {
      print('Google Sign In error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to sign in with Google: ${e.toString()}'),
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }

  Future<void> _signInWithAccount(GoogleSignInAccount account) async {
    try {
      // Get authentication details
      final auth = await account.authentication;

      // Send the authentication data back to the web app
      final authData = {
        'email': account.email,
        'displayName': account.displayName,
        'photoUrl': account.photoUrl,
        'id': account.id,
        'idToken': auth.idToken,
        'accessToken': auth.accessToken,
      };

      // Inject JavaScript to pass auth data to the web app
      // Try multiple ways to pass the data
      await _controller.runJavaScript('''
        // Try to call the web app's handler
        if (window.handleGoogleSignIn) {
          window.handleGoogleSignIn(${jsonEncode(authData)});
        } else if (window.clerk) {
          // If using Clerk, try to simulate the auth flow
          console.log('Google auth data:', ${jsonEncode(authData)});
        } else {
          // Fallback: try to fill forms or trigger events
          const event = new CustomEvent('googleSignInSuccess', { detail: ${jsonEncode(authData)} });
          document.dispatchEvent(event);
        }
      ''');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Signed in as ${account.displayName ?? account.email}')),
        );
      }

    } catch (e) {
      print('Error signing in with account: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to authenticate: ${e.toString()}')),
        );
      }
    }
  }

  Future<bool> _showExitConfirmationDialog() async {
     final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false, // Prevent dismissing by tapping outside
      builder: (BuildContext context) {
        return PopScope(
          canPop: false, // Prevent back button from dismissing dialog
          child: AlertDialog(
            backgroundColor: AppConstants.primaryColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppConstants.borderRadius),
            ),
            title: Text(
              AppLocalizations.of(context)!.exitDialogTitle,
              style: TextStyle(color: AppConstants.accentColor, fontWeight: FontWeight.bold, fontSize: 20),
            ),
            content: Text(
              AppLocalizations.of(context)!.exitDialogContent,
              style: TextStyle(color: AppConstants.accentColor.withOpacity(0.7), fontSize: 16),
            ),
            actions: <Widget>[
              TextButton(
                child: Text(
                  AppLocalizations.of(context)!.cancelText,
                  style: TextStyle(color: AppConstants.accentColor.withOpacity(0.7), fontSize: 16),
                ),
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
              ),
              TextButton(
                child: Text(
                  AppLocalizations.of(context)!.exitText,
                  style: TextStyle(color: AppConstants.errorColor, fontSize: 16, fontWeight: FontWeight.bold),
                ),
                onPressed: () {
                  Navigator.of(context).pop(true);
                },
              ),
            ],
          ),
        );
      },
    );
    return result ?? false;
  }

  Future<bool> _handleBackNavigation() async {
     // Always show exit confirmation dialog when back button is pressed
     final shouldExit = await _showExitConfirmationDialog();

     if (shouldExit) {
       // Exit the app
       SystemNavigator.pop(); // This will exit the app
      return true; // Return true to indicate we handled the back navigation
    }

    return shouldExit;
  }


  Widget _buildOfflineErrorWidget() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.wifi_off,
            size: 80,
            color: AppConstants.accentColor.withOpacity(0.7),
          ),
          const SizedBox(height: 20),
          Text(
            AppLocalizations.of(context)!.noInternetTitle,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppConstants.accentColor,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 10),
          Text(
            AppLocalizations.of(context)!.noInternetMessage,
            style: TextStyle(
              fontSize: 16,
              color: AppConstants.accentColor.withOpacity(0.7),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: _retryLoading,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppConstants.primaryColor,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            ),
            child: Text(
              AppLocalizations.of(context)!.retryText,
              style: const TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWebErrorWidget() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline,
            size: 80,
            color: AppConstants.errorColor.withOpacity(0.7),
          ),
          const SizedBox(height: 20),
          Text(
            AppLocalizations.of(context)!.webErrorTitle,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppConstants.accentColor,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 10),
          Text(
            AppLocalizations.of(context)!.webErrorMessage,
            style: TextStyle(
              fontSize: 16,
              color: AppConstants.accentColor.withOpacity(0.7),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: _retryLoading,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppConstants.primaryColor,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            ),
            child: Text(
              AppLocalizations.of(context)!.retryText,
              style: const TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false, // Prevent default back behavior
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return; // If already popped, do nothing
        final shouldPop = await _handleBackNavigation();
        if (shouldPop && mounted) {
          // If user confirmed exit, close the app
          // Note: This will actually close the app since canPop is false
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppLocalizations.of(context)!.appTitle),
          backgroundColor: AppConstants.primaryColor,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            tooltip: 'Back',
            onPressed: () async {
              // Handle back button press from app bar
              await _handleBackNavigation();
            },
          ),
        ),
        body: Stack(
          children: [
            Semantics(
              label: 'BRIXS web content',
              hint: 'Main application content loaded from web',
              child: WebViewWidget(controller: _controller),
            ),
            if (_isLoading)
              const _LoadingOverlay(),
            if (_isOffline)
              _OfflineErrorOverlay(onRetry: _retryLoading),
            if (_hasWebError && !_isOffline)
               _WebErrorOverlay(onRetry: _retryLoading),
          ],
        ),
        floatingActionButton: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Semantics(
              button: true,
              label: 'Test Google Sign In',
              hint: 'Shows available Google accounts for testing',
              child: FloatingActionButton(
                onPressed: () async {
                  await _showGoogleAccountPicker();
                },
                child: const Icon(Icons.account_circle),
                tooltip: 'Test Google Sign In',
                backgroundColor: Colors.blue,
                heroTag: 'google',
              ),
            ),
            const SizedBox(height: 16),
            Semantics(
              button: true,
              label: 'Test back navigation',
              hint: 'Simulates pressing the back button to test exit dialog',
              child: FloatingActionButton(
                onPressed: () async {
                  // Test the back navigation logic
                  final result = await _handleBackNavigation();
                  print('Back navigation result: $result');
                },
                child: const Icon(Icons.arrow_back),
                tooltip: 'Test Back Navigation',
                heroTag: 'back',
              ),
            ),
            const SizedBox(height: 16),
            Semantics(
              button: true,
              label: 'Test loading screen',
              hint: 'Shows the loading screen for testing purposes',
              child: FloatingActionButton(
                onPressed: () {
                  // Test loading screen
                  setState(() {
                    _isLoading = true;
                  });
                  Future.delayed(AppConstants.loadingTestDuration, () {
                    if (mounted) {
                      setState(() {
                        _isLoading = false;
                      });
                    }
                  });
                  print('Loading screen test triggered');
                },
                child: const Icon(Icons.refresh),
                tooltip: 'Test Loading Screen',
                backgroundColor: Colors.green,
                heroTag: 'loading',
              ),
            ),
            const SizedBox(height: 16),
            Semantics(
              button: true,
              label: 'Test exit dialog',
              hint: 'Shows the exit confirmation dialog for testing purposes',
              child: FloatingActionButton(
                onPressed: () async {
                  // Test exit dialog directly
                  final result = await _showExitConfirmationDialog();
                  print('Direct exit dialog result: $result');
                },
                child: const Icon(Icons.exit_to_app),
                tooltip: 'Test Exit Dialog',
                backgroundColor: Colors.red,
                heroTag: 'exit',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LoadingOverlay extends StatelessWidget {
  const _LoadingOverlay();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppConstants.backgroundColor,
      child: const Center(
        child: BrixsLoadingScreen(),
      ),
    );
  }
}

class _OfflineErrorOverlay extends StatelessWidget {
  const _OfflineErrorOverlay({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppConstants.backgroundColor,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.wifi_off,
                size: 80,
                color: AppConstants.accentColor.withOpacity(0.7),
              ),
              const SizedBox(height: 20),
              Text(
                AppLocalizations.of(context)!.noInternetTitle,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppConstants.accentColor,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                AppLocalizations.of(context)!.noInternetMessage,
                style: TextStyle(
                  fontSize: 16,
                  color: AppConstants.accentColor.withOpacity(0.7),
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: onRetry,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppConstants.primaryColor,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                child: Text(
                  AppLocalizations.of(context)!.retryText,
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WebErrorOverlay extends StatelessWidget {
  const _WebErrorOverlay({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppConstants.backgroundColor,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.error_outline,
                size: 80,
                color: AppConstants.errorColor.withOpacity(0.7),
              ),
              const SizedBox(height: 20),
              Text(
                AppLocalizations.of(context)!.webErrorTitle,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppConstants.accentColor,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                AppLocalizations.of(context)!.webErrorMessage,
                style: TextStyle(
                  fontSize: 16,
                  color: AppConstants.accentColor.withOpacity(0.7),
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: onRetry,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppConstants.primaryColor,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                child: Text(
                  AppLocalizations.of(context)!.retryText,
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

