// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:brixs_webview_app/main.dart';
import 'package:brixs_webview_app/widgets/loading_screen.dart';
import 'package:brixs_webview_app/widgets/splash_screen.dart';
import 'package:brixs_webview_app/l10n/app_localizations.dart';
import 'package:brixs_webview_app/constants.dart';

void main() {
  testWidgets('Onboarding screen displays correctly', (WidgetTester tester) async {
    // Build the onboarding screen with localization
    await tester.pumpWidget(
      MaterialApp(
        localizationsDelegates: AppLocalizations.localizationsDelegates,
        supportedLocales: AppLocalizations.supportedLocales,
        home: const SplashScreen(),
      ),
    );

    // Wait for a short time to let the screen build
    await tester.pump(const Duration(milliseconds: 100));

    // Verify that the onboarding screen elements are present
    expect(find.text('BRIXS'), findsOneWidget);
    expect(find.text('Purchase Platform'), findsOneWidget);
    expect(find.text('Slide to Continue'), findsOneWidget);

    // Verify that the bitcoin icon is present
    expect(find.byIcon(Icons.currency_bitcoin), findsOneWidget);

    // Verify app feature information is displayed
    expect(find.text('Secure Transactions'), findsOneWidget);
    expect(find.text('Fast & Reliable'), findsOneWidget);
    expect(find.text('24/7 Support'), findsOneWidget);

    // Verify slider is present
    expect(find.byType(Slider), findsOneWidget);
  });

  testWidgets('Loading screen builds without errors', (WidgetTester tester) async {
    // Build the loading screen with localization
    await tester.pumpWidget(
      MaterialApp(
        localizationsDelegates: AppLocalizations.localizationsDelegates,
        supportedLocales: AppLocalizations.supportedLocales,
        home: const Scaffold(
          body: BrixsLoadingScreen(),
        ),
      ),
    );

    // Wait for a short time
    await tester.pump(const Duration(milliseconds: 100));

    // Verify that the widget builds successfully (no exceptions thrown)
    expect(find.byType(BrixsLoadingScreen), findsOneWidget);
  });

  testWidgets('Constants are properly defined', (WidgetTester tester) async {
    // Test that constants have expected values
    expect(AppConstants.appTitle, 'BRIXS Purchase');
    expect(AppConstants.brixsText, 'BRIXS');
    expect(AppConstants.loadingText, 'Loading...');
    expect(AppConstants.primaryColor, const Color(0xFF14152b));
    expect(AppConstants.backgroundColor, const Color(0xFF0a0a0a));
    expect(AppConstants.minimumLoadingTime, const Duration(milliseconds: 800));
  });

  testWidgets('Localization works correctly', (WidgetTester tester) async {
    // Test localization directly
    await tester.pumpWidget(
      MaterialApp(
        localizationsDelegates: AppLocalizations.localizationsDelegates,
        supportedLocales: AppLocalizations.supportedLocales,
        locale: const Locale('en'),
        home: Builder(
          builder: (context) {
            final localizations = AppLocalizations.of(context)!;
            return Scaffold(
              body: Column(
                children: [
                  Text(localizations.appTitle),
                  Text(localizations.brixsText),
                  Text(localizations.loadingText),
                ],
              ),
            );
          },
        ),
      ),
    );

    await tester.pump();

    // Verify localized text is displayed
    expect(find.text('BRIXS Purchase'), findsOneWidget);
    expect(find.text('BRIXS'), findsOneWidget);
    expect(find.text('Loading...'), findsOneWidget);
  });
}
