// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'BRIXS Purchase';

  @override
  String get brixsText => 'BRIXS';

  @override
  String get loadingText => 'Loading...';

  @override
  String get exitDialogTitle => 'Exit BRIXS';

  @override
  String get exitDialogContent => 'Are you sure you want to exit the app?';

  @override
  String get cancelText => 'Cancel';

  @override
  String get exitText => 'Exit';

  @override
  String get noInternetTitle => 'No Internet Connection';

  @override
  String get noInternetMessage =>
      'Please check your internet connection and try again.';

  @override
  String get retryText => 'Retry';

  @override
  String get webErrorTitle => 'Connection Error';

  @override
  String get webErrorMessage => 'Unable to load the page. Please try again.';
}
