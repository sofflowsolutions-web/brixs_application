// App Constants
import 'package:flutter/material.dart';

class AppConstants {
  // Colors
  static const Color primaryColor = Color(0xFF14152b);
  static const Color backgroundColor = Color(0xFF0a0a0a);
  static const Color secondaryColor = Color(0xFF2d3748);
  static const Color accentColor = Colors.white;
  static const Color errorColor = Colors.red;

  // Durations
  static const Duration loadingAnimationDuration = Duration(seconds: 2);
  static const Duration minimumLoadingTime = Duration(milliseconds: 800);
  static const Duration loadingTestDuration = Duration(seconds: 2);

  // Strings
  static const String appTitle = 'BRIXS Purchase';
  static const String brixsText = 'BRIXS';
  static const String loadingText = 'Loading...';
  static const String exitDialogTitle = 'Exit BRIXS';
  static const String exitDialogContent = 'Are you sure you want to exit the app?';
  static const String cancelText = 'Cancel';
  static const String exitText = 'Exit';

  // URLs
  static const String websiteUrl = 'https://purchase.brixs.live/';

  // User Agent
  static const String userAgent = 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36';

  // CSS for webview
  static const String nativeStylingCss = '''
    /* Hide scrollbars */
    ::-webkit-scrollbar {
      display: none;
    }

    /* Hide address bar and navigation elements */
    .browser-ui, .address-bar, .navigation-bar {
      display: none !important;
    }

    /* Ensure full screen experience */
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      overflow-x: hidden;
    }

    /* Hide any browser-specific UI */
    #browser-ui, #address-bar, #navigation {
      display: none !important;
    }
  ''';

  // Animation values
  static const double loadingScaleBegin = 0.8;
  static const double loadingScaleEnd = 1.2;
  static const double dotOpacityBegin = 0.3;
  static const double dotOpacityEnd = 1.0;
  static const double dotAnimationDelay = 0.2;
  static const double dotAnimationDuration = 0.4;

  // UI dimensions
  static const double logoSize = 60.0;
  static const double titleFontSize = 32.0;
  static const double subtitleFontSize = 16.0;
  static const double dotSize = 8.0;
  static const double borderRadius = 16.0;
  static const double shadowBlurRadius = 20.0;
  static const double shadowSpreadRadius = 5.0;
}